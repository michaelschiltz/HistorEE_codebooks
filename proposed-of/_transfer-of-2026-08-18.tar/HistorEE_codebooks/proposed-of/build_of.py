#!/usr/bin/env python3
"""Propose organizational_forms rows for societas_maris, and settle mudaraba.

Emits proposed-of/ files; with --apply, writes into the working tree.
"""
import csv, sys, pathlib

HEADER = ["record_id","type_id","char_id","value","confidence","articulation",
          "source_ref","source_lang","coder","source_read","reviewed_by",
          "review_status","notes"]

VD    = "van Doosselaere 2009, 64-68 (Genoese notarial cartularies; 6,764 commenda ties 1154-1315)"
HARR7 = "Harris 2007, 9-13"
HELD  = "Held 2025, 22"

PAIR = ("PAIRED WITH commenda, which is coded on these same eleven characteristics and no others, so the two rows are "
        "comparable cell for cell. No cell here was filled from commenda's source and none of commenda's cells was touched.")

R = [
("societas_maris","TS2","single-venture","high",".NR",VD,"en","partial",
 "'The agreement was for the duration of one voyage' (van Doosselaere 2009, 65); time-based commercial associations 'were very "
 "rare' (65 n.5). Same value as commenda. " + PAIR),

("societas_maris","AP3","1","medium",".NR",VD+"; "+HARR7,"en","partial",
 "The travelling party's exposure is capped at the third he contributed, so his personal estate is not reachable for the "
 "venture's losses beyond it - the same reading already recorded in commenda's AP3 note ('in the bilateral societas maris his "
 "loss is capped at his contribution'). Coded 1 to match commenda deliberately, so that the pair cannot separate on this cell by "
 "accident. "
 "BUT THE VALUE MAY BE WRONG FOR BOTH ROWS, AND THIS SHOULD BE LOOKED AT. Harris 2007, 11 describes the arrangement as an "
 "'ASYMMETRIC owners' shielding': the commenda's asset pool 'was reachable to creditors of the commenda AND to creditors of the "
 "traveling party. So was the traveling party's private pool of assets. But the investing party's private pool of assets was "
 "not' - and at 9, 'the traveling party would bear SOLE LIABILITY TOWARD THIRD PARTIES'. AP3 asks whether members' personal "
 "assets are shielded from entity creditors. One member's are and the other's are not, which is what P is for. Both commenda and "
 "societas_maris are candidates for AP3=P. NOT CHANGED HERE: recoding an existing row on a reading of a source the original "
 "coder may have considered is the maintainer's call, and doing it in the same batch that adds the comparison form would confound "
 "the two changes. Raised in logbook 1, 2026-08-18. " + PAIR),

("societas_maris","LR1","limited","medium",".NR",VD+"; "+HARR7,"en","partial",
 "Each party's exposure for the venture's losses is bounded by his own contribution. Coded to match commenda, and carrying the "
 "same caveat as AP3: sole liability toward third parties sits on the traveller (Harris 2007, 9), which is not 'limited' as to "
 "him. Both rows would move together if that reading is adopted. " + PAIR),

("societas_maris","LR2","coupled","high",".NR",VD,"en","partial",
 "Both parties are bound to the realised outcome: 'the commendae outcome depended solely on the success of the business "
 "enterprise, and was thus akin to a one-voyage venture capital partnership' (van Doosselaere 2009, 66), and the traveller has "
 "his own capital in it besides. Same value as commenda, and coded high here where commenda's rests on [verify]."),

("societas_maris","LR3","1","high","articulated",VD,"en","partial",
 "Returns follow the venture, not a fixed claim - and the two sides follow DIFFERENT rules, which is the interesting part. "
 "Profit is split EQUALLY ('the equal division of profit between the traveler and the investor'); loss is split PRO RATA TO "
 "CAPITAL ('the liability for loss was proportional to the respective initial investments of the participants'), and the "
 "contributions are customarily one third and two thirds (van Doosselaere 2009, 65). So the traveller takes half the upside and "
 "a third of the downside. "
 "THE ASYMMETRY IS THE MIRROR IMAGE OF THE 'ISQA'S. There the manager's profit share exceeds his loss share to compensate his "
 "labour and to keep the arrangement clear of ribbit (organizational_forms isqa LR3, 'sekharo ke-po'el batel'); here it exceeds "
 "it for the first reason alone, with no doctrinal second reason. Two traditions reach the same drafting solution to the "
 "labour-compensation problem, one of them under a usury constraint and one of them not - which is evidence that the constraint "
 "is not what produced the solution. LR3's ternary cannot hold the asymmetry; it is here in the note."),

("societas_maris","LR4","0","medium",".NR",VD,"en","partial",
 "Bilateral, not mutualised across a membership. Note that Genoese investors DID diversify - splitting a stake across several "
 "travellers, which van Doosselaere 2009, 66 and Pryor 1984, 437 both describe - but that is a portfolio held by one investor "
 "across contracts, not risk mutualised inside this one. Same value and same reasoning as commenda and qirad. " + PAIR),

("societas_maris","LR5",".NA",".NA",".NA",".NA",".NA",".NA",
 "Inapplicable: propagates from LR4=0. No pooled baskets whose correlation could be asked about."),

("societas_maris","CF1","P","high",".NR",VD,"en","partial",
 "THE CAPITAL-LABOUR ASYMMETRY IS HALF PRESENT, AND THIS IS A STRUCTURAL STATE RATHER THAN A HEDGE. The investor supplies "
 "capital only; the traveller supplies capital AND labour, 'always to the ratio one-third traveler, two-thirds investor' (van "
 "Doosselaere 2009, 65). The labour is one-sided, the capital is not. CF1's question - 'one party supplies capital, another "
 "labour or enterprise' - is therefore true of the labour and false of the capital, which is exactly what P records. "
 "Coded 1 for commenda, where the traveller contributes nothing but labour. This is the second cell on which the pair separates "
 "and the only one outside the WP1 component sets. Confidence high: the fact is not in doubt, only its representation. "
 "CF1=P does not block CF2 - see check_dependence's BLOCKING table, which gates CF2 on CF1 in {0, .NA}."),

("societas_maris","CF2","0","high",".NR",VD,"en","partial",
 "THE CELL THAT DOES *NOT* SEPARATE THE PAIR, AND IT IS THE MOST INFORMATIVE CELL IN THIS BATCH. CF2 asks whether the working "
 "party bears loss of THE PRINCIPAL'S capital. He does not: 'the liability for loss was proportional to the respective initial "
 "investments' (van Doosselaere 2009, 65), so the traveller bears his own third and none of the investor's two thirds. Same "
 "value as commenda, qirad and ortoq_equity. "
 "WHAT THIS DOES TO THE agent-loss-exposure DEPENDENCE GROUP. The group is {AP3, CF2, LR1, LR6}. Before this row, LR6 separated "
 "from the other three only via forms with CF2=.NA - asiento_averia and bazacle_mill, neither of which has a capital-labour "
 "asymmetry at all - which check_dependence.py reports as 'weak: via .NA'. This row produces the signature "
 "{AP3:1, CF2:0, LR1:limited, LR6:symmetric}, which did not previously exist: THREE MEMBERS HELD IDENTICAL TO commenda WHILE THE "
 "FOURTH MOVES. CF2=0 now occurs with LR6 in both symmetric and upside-only on substantive values. See logbook 4, 2026-08-18."),

("societas_maris","CF3","bilateral","high",".NR",VD,"en","partial",
 "Two principals. Same value as commenda. "
 "TERMINOLOGICAL WARNING, BECAUSE THIS CELL IS A TRAP. CF3's 'bilateral' means TWO PRINCIPALS, as against multilateral. The "
 "commenda literature's 'bilateral commenda' - van Doosselaere 2009, 65, Held 2025, 7 - means BOTH PARTIES INVEST, as against "
 "unilateral, and says nothing about how many they are. This row is 'bilateral' in both senses and commenda is bilateral in the "
 "first sense only, so the collision is invisible here and will not be invisible the first time a multilateral commenda is "
 "coded. Van Doosselaere 2009, 66 records those: 'a single traveling party could pool together goods from numerous investing "
 "parties'; 132 of the 150 contracts for the Saint Esprit's 1248 voyage were commendae, one merchant holding thirteen of them "
 "with eleven different investors (Harris 2007, 12 n.17). Such a row would read CF3=multilateral and would still be a unilateral "
 "commenda."),

("societas_maris","LR6","symmetric","high",".NR",VD+"; "+HARR7,"en","partial",
 "THE DISCRIMINATING CELL. The traveller is exposed both ways: he takes half the profit and bears a third of the loss, because a "
 "third of the capital is his (van Doosselaere 2009, 65). Contrast commenda LR6=upside-only, where 'the traveler... bore no "
 "capital risk' - a call bounded below at zero. Harris 2020, via the existing commenda LR6 note, says the same: 'in the "
 "bilateral societas maris his downside is capped at his own contribution, which is still bounded, not open-ended'. Bounded is "
 "not zero, and LR6 asks the direction of exposure, not its size. "
 "THIS IS THE SAME FACT AS loss_mitigation_forms societas_maris RB1/RB2=shared, SEEN FROM THE AGENT'S SIDE INSTEAD OF THE LOSS'S. "
 "It is one piece of evidence appearing in two datasets, not two confirmations, and no comparative claim may count it twice. "
 "What the two datasets add to each other is that RB1/RB2 splits the peril from the market and LR6 does not, while LR6 gives the "
 "direction of the agent's exposure and RB1/RB2 does not. See logbook 4, 2026-08-18."),
]


def main():
    start = 283
    rows = []
    for i, (t, c, v, conf, art, sref, slang, sread, note) in enumerate(R):
        rows.append({"record_id": "OF-%04d" % (start + i), "type_id": t, "char_id": c,
                     "value": v, "confidence": conf, "articulation": art,
                     "source_ref": sref, "source_lang": slang, "coder": "ai",
                     "source_read": sread, "reviewed_by": "none",
                     "review_status": "unreviewed", "notes": " ".join(note.split())})
    out = pathlib.Path("proposed-of"); out.mkdir(exist_ok=True)
    p = out / "organizational_forms-rows.csv"
    with p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=HEADER, lineterminator="\n")
        w.writeheader(); w.writerows(rows)
    print("wrote %d rows -> %s (%s..%s)" % (len(rows), p, rows[0]["record_id"], rows[-1]["record_id"]))
    if "--apply" in sys.argv:
        d = pathlib.Path("datasets/organizational_forms/data.csv")
        with d.open("a", newline="", encoding="utf-8") as fh:
            csv.DictWriter(fh, fieldnames=HEADER, lineterminator="\n").writerows(rows)
        print("appended to", d)


if __name__ == "__main__":
    main()
