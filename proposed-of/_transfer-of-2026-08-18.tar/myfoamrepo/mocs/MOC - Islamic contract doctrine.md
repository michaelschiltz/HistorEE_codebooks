---
title: MOC - Islamic contract doctrine
type: moc
tags: [moc]
project: HistorEE
created: 2026-07-20
status: seed
---

# MOC — Islamic contract doctrine

Thematic hub for the fiqh apparatus bearing on finance: *gharar*, *maysir*, *riba*, *salam*, *hiyal*, the *qirad*/*mudaraba*, and the fraud/breach-of-trust categories.

## Notes

- [[Islamic doctrine refuses risk-commodification at step one]]
- [[The qirad envelops the sea loan]]
- [[Naviganti - Latin Christendom rejected the sea loan too]]
- [[Scuttling rewards fraud in the sea loan]]
- [[The mudaraba is revocable not locked in]]
- [[Skin in the game is asymmetric in the mudaraba]]
- [[The waqf partition converts absence into refusal]]
- [[The waqf and the nación flamenca diverge only at legal personality]]
- [[Entitlement by liability versus entitlement by membership]]
- [[The qirad's antecedents are Sasanian not Sogdian]]
- [[The determinate-contingent typology carries the richness]]
- [[The commenda and the qirad do not separate on loss allocation]]
- [[A route clause conditions the investor's peril in three traditions]]
- [[A migrated institution collects local names not local forms]]

## Comparative — Jewish contract doctrine

The *ribbit* material is filed here rather than in a separate hub, because its value to the project is comparative: the same refusal of the priced-certain return, met by a form that declines to shield the agent.

- [[Ribbit mandates exposure rather than forbidding gain]]
- [[The isqa refuses the agent's shield]]
- [[The heter iska restores the fixed return by evidentiary barrier]]
- [[isqa]]

## Open citations to verify

- *Naviganti* — Liber Extra X 5.19.19, 1234 (confirm numbering)
- ḥadd/taʿzīr hadith wording on betrayal of trust (*khiyāna* vs *sariqa*)
- Sasanian genealogy of the *qirad* (*hambāyīh*; Morony 2017; cf. Udovitch 1962) — pending Part 2 WP1 note
- *ʿaqd jāʾiz* classification of the *mudaraba*, and the Maliki restriction on revocation once the agent has commenced work — schools diverge; confirm before the revocability claim carries weight
- Harris's engagement with Kuran in chapter 12 — confirm he treats non-perpetuity directly rather than in passing
- *al-kharāj bi-l-ḍamān* and *al-ghunm bi-l-ghurm* — hadith attribution and standard *qāʿida fiqhiyya* formulations
- Q 59:7 circulation norm — confirm the *fayʾ* context before generalising it to an anti-concentration principle
- Harris on the *waqf* in ch. 12 as a candidate origin for the corporation — confirm he frames it as candidate rather than analogue
- R. Mendel Avigdors of Cracow — dates (given as d. 1599) and the received *nusaḥ* of the *Shetar Heter ʿIsqa ke-Tikkun MaHaRaM*; the oath/witness clause varies between recensions and the comparison needs a specific text, not the modern bank form
- Whether the *ʿisqa* sugya (BT *Bava Metzia* 104b) has already been read against Sasanian partnership law in the Irano-Talmudica literature — sweep before claiming the lead is novel

## Links

- [[MOC - Risk-sharing vs risk-pricing]]
- [[MOC - HistorEE]]


[Islamic doctrine refuses risk-commodification at step one]: <../notes/Islamic doctrine refuses risk-commodification at step one.md> "Islamic doctrine refuses risk-commodification at step one"
[The qirad envelops the sea loan]: <../notes/The qirad envelops the sea loan.md> "The qirad envelops the sea loan"
[Naviganti - Latin Christendom rejected the sea loan too]: <../notes/Naviganti - Latin Christendom rejected the sea loan too.md> "Naviganti - Latin Christendom rejected the sea loan too"
[Scuttling rewards fraud in the sea loan]: <../notes/Scuttling rewards fraud in the sea loan.md> "Scuttling rewards fraud in the sea loan"
[MOC - Risk-sharing vs risk-pricing]: <MOC - Risk-sharing vs risk-pricing.md> "MOC - Risk-sharing vs risk-pricing"
[MOC - HistorEE]: <MOC - HistorEE.md> "MOC - Clearing and Settling the Realm"
