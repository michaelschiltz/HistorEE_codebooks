#!/usr/bin/env python3
"""Update the four allocation-anchor rows in vocabularies/loss_mitigation_type.csv.

Writes proposed/loss_mitigation_type-rows.csv (the four replacement rows, with
header) and, with --apply, rewrites the vocabulary in place.
"""
import csv, sys, pathlib

TRIAD = ("Coded 2026-08-18 together with qirad_alloc, isqa_alloc and societas_maris; "
         "see logbook 2, 2026-08-18 for the inclusion decisions and logbook 4 for what the batch did to MC1 and RB4.")

NEW = {
"commenda_alloc": dict(
  key_source=(
    "CROSS-REFERENCE: coded as an entity-question in organizational_forms 'commenda'. Here only its loss-allocation "
    "characteristics; LS1, LS2 and LS3 are deliberately NOT coded because LS3 is the direct analogue of AP3, already carried there. "
    "Held 2025 (Statute of Dubrovnik 1272, lib. VII 50-51 and lib. III 46; MHR I-IV, 53 notarial contracts 1278-1301) - the "
    "transactional base for RB1, RB4, VF1 and VF2; Harris 2007, 9-13 for RB2; Gonzalez de Lara 2002 (6-page dissertation summary "
    "only) for the Venetian verification argument; Pryor 1984 (OCR'd from an image scan) for prevalence at Marseilles and for "
    "'women commendators were liable for loss just like men', but NOT for risk allocation, which the article does not treat. "
    "van Doosselaere 2009, 64-68 and 130 (PDF acquired 2026-08-18) - the Genoese corpus, corroborating RB1 and RB4 and supplying "
    "PR1's strongest evidence and a fourth attestation of the route-and-goods restriction clause. "
    "NOT HELD WITH TEXT and wanted: Lopez & Raymond (metadata stub only, the translated Genoese and Venetian contracts), "
    "Astuti 1970 (linked URL, no text), Harris 2020 Going the Distance ch. 5. " + TRIAD),
  cooccurs_with="qirad_alloc;isqa_alloc;societas_maris;sea_loan;commenda@organizational_forms",
  cooccurrence_basis="same-institution",
  boundary_basis="contemporary-terminology",
  boundary_confidence="high",
),
"qirad_alloc": dict(
  key_source=(
    "CROSS-REFERENCE: see organizational_forms 'qirad'. Here only its loss-allocation characteristics; LS3 not coded, it would "
    "restate AP3 there. Ramli 2018, 95-98 and 105 (analysis and partial translation of al-Sarakhsi, Kitab al-Mudarabah of "
    "al-Mabsut 22) - the doctrinal base for RB1, RB2, RB4 and PR1; Ackerman-Lieberman 2011, 663-664 for al-Nuwayri's safe-routes "
    "clause and for the Geniza documents that cut against the doctrinal coding; Harris 2007, 9-13. "
    "NOT HELD WITH TEXT and wanted: Udovitch 1970 Partnership and Profit (Zotero item RPV4XSBG is a linked-URL stub - the standard "
    "monograph for this row is NOT in the library), Udovitch 1962 and 1965, Khalilieh 2020 (saved attachment is a paywall landing "
    "page, abstract only). VF1 is .NR for exactly this reason and must not be read as a differentia against commenda_alloc. "
    "boundary_basis=contemporary-terminology IS ABOUT THE LOSS-ALLOCATION CHARACTERISTICS AND NOTHING WIDER. One real structural "
    "contrast with commenda_alloc is known and no cell in this dataset holds it: the qirad's profit ratio is negotiated and "
    "responds to market conditions and network position, splits from half-and-half to 1/20-19/20 being contemplated in the "
    "manuscripts, whereas the Genoese ratio was customary and invariant until the late thirteenth century (van Doosselaere 2009, "
    "68, reading Udovitch 1970, 190-6). It is not a peril price, so PR1 cannot carry it. See logbook 4, 2026-08-18 (vi). " + TRIAD),
  cooccurs_with="commenda_alloc;isqa_alloc;societas_maris;qirad@organizational_forms",
  cooccurrence_basis="same-institution",
  boundary_basis="contemporary-terminology",
  boundary_confidence="high",
),
"isqa_alloc": dict(
  key_source=(
    "CROSS-REFERENCE: see organizational_forms 'isqa' (32 rows). Here only its loss-allocation characteristics; LS3 not coded, it "
    "would restate AP3=0 there. Ackerman-Lieberman 2011, 662-664 (Maimonides, Laws of Agency and Partnership 6:1-2 and 2:3-7; "
    "BT Bava Metzia 104b behind it) - the base for RB1, RB2, RB4 and PR1. "
    "DISPUTE HELD OPEN AS A CODING, NOT RESOLVED: Ackerman-Lieberman 2011, 664 reports that Geniza legal documents for investment "
    "partnerships 'allocate both partners a share of both profits and losses, with very few documents indemnifying the active "
    "partner'. On his reading those instruments are 'isqa-shaped and Jewish law governed practice; on Udovitch's and Goitein's they "
    "are qirad in practice, in which case qirad_alloc RB2 is doctrine the documents contradict. Settling it needs "
    "Ackerman-Lieberman 2014 The Business of Identity, 2012 Commercial Forms and Legal Norms, Gamoran 2008 and Cohen 2017 - all "
    "four metadata-only in the library. "
    "INDEPENDENT CORROBORATION: van Doosselaere 2009, 68 reaches the same allocation from the Genoese side and from Pryor and "
    "Udovitch rather than from the Talmud - the isqua 'suggest[s] the idea of debt, or at least equal and joint liability, which "
    "severely restricted the pairing of participants with substantial differences in wealth'. " + TRIAD),
  cooccurs_with="commenda_alloc;qirad_alloc;isqa@organizational_forms",
  cooccurrence_basis="same-institution",
  boundary_basis="structural-difference",
  boundary_confidence="high",
),
"societas_maris": dict(
  key_source=(
    "van Doosselaere 2009, 64-68 and 130 (Zotero V4S222VJ; PDF acquired 2026-08-18, AFTER the first pass of this row - the earlier "
    "coding was thin and medium throughout for want of it). The Genoese notarial cartularies, 6,764 commenda ties 1154-1315, 93 per "
    "cent of all coded maritime ties: p.65 states the unilateral and bilateral liability rules side by side and is the base for RB1, "
    "RB2, RB3 and RB4; pp.66-67 for PR1 (4,860 ties 1154-1265, payout invariant across destination and size). Held 2025, 22 for the "
    "Ragusan contracts sharing lucrum and damnum in the same proportions; Harris 2007, 12. "
    "STILL WANTED: Lopez & Raymond, Medieval Trade in the Mediterranean World, 174-184, where the societas maris contracts are "
    "translated (Zotero DTYK94N3 is a Semantic Scholar metadata stub, wrongly typed conferencePaper, with no text) - it would supply "
    "the quoted clause van Doosselaere paraphrases; Astuti 1970. "
    "DISSENT, RECORDED NOT RESOLVED: Pryor 1977, Luzzatto 1961, 119 and van Doosselaere 2009, 65 n.7 all hold unilateral and "
    "bilateral commenda to be 'essentially the same agreement', the choice turning on the traveller's wealth. They reach that on the "
    "PAYOUT, where the economics are identical by construction; on the LOSS they are not. This census measures the loss. "
    "NAMING, SETTLED FROM HELD 2025: the two names on this row are not two regional variants of one thing. In Venetian documents "
    "'collegantia' is used EXCLUSIVELY for the bilateral commenda and the unilateral form has no designation at all (Held 2025, 9, "
    "after Pryor 1977, 10), so Venetian collegantia and Genoese societas maris do both name the bilateral form and the row's title "
    "is coherent. But the RAGUSAN collegantia is, on Held's conclusion, 'a local variant of the UNILATERAL commenda' - so it belongs "
    "under commenda_alloc, not here, and the split queued in logbook 2 (2026-08-16) is misfiled. Not split; see logbook 2, "
    "2026-08-18. NOT coded in organizational_forms (0 rows there, as for mudaraba). " + TRIAD),
  cooccurs_with="commenda_alloc;qirad_alloc;sea_loan;marine_insurance",
  cooccurrence_basis="same-institution",
  boundary_basis="structural-difference",
  boundary_confidence="high",
),
}

def main():
    p = pathlib.Path("vocabularies/loss_mitigation_type.csv")
    with p.open(encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        header = rd.fieldnames
        rows = list(rd)
    changed = []
    for r in rows:
        if r["code"] in NEW:
            for k, v in NEW[r["code"]].items():
                r[k] = " ".join(v.split())
            changed.append(dict(r))
    assert len(changed) == 4, changed
    out = pathlib.Path("proposed"); out.mkdir(exist_ok=True)
    q = out / "loss_mitigation_type-rows.csv"
    with q.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=header, lineterminator="\n")
        w.writeheader(); w.writerows(changed)
    print("wrote 4 replacement type rows ->", q)
    if "--apply" in sys.argv:
        with p.open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=header, lineterminator="\n")
            w.writeheader(); w.writerows(rows)
        print("rewrote", p)

if __name__ == "__main__":
    main()
